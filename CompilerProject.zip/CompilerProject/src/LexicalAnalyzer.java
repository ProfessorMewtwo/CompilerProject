import java.io.*;
import java.util.*;


public class LexicalAnalyzer {
	
	public static String [] Integers = {"0","1","2","3","4","5","6","7","8","9"};
	public static ArrayList<String> SetIntegers = new ArrayList<String>();
	public static String [] Letters = {"a","A","b","B","c","C","d","D","e","E","f","F","g","G","h","H","i","I","j","J","k","K","l","L","m","M","n","N","o","O","p","P","q","Q","r","R","s","S","t","T","u","U","v","V","w","W","x","X","y","Y","z","Z","_"};
	public static ArrayList<String> SetLetters = new ArrayList<String>();
	
	public static ArrayList<SMBLTable> Symbols = new ArrayList<SMBLTable>();
	public static ArrayList<ReservedWordFile> RWF = new ArrayList<ReservedWordFile>();
	public static ArrayList<String> TokenFile = new ArrayList<String>();
	
	public static ArrayList<Token> results = new ArrayList<Token>();
	
	public static String buffer [] = new String [72];
	public static int b = 0;
	public static int IDpoint = 40;
	
	public static class Token{
		public final String a; public final String b; public final String c;
		
		public Token(String a, String b, String c)
		{
			this.a = a;
			this.b = b;
			this.c = c;	
		}		
	}

	public static class SMBLTable{
		public final String a; public final int b;
		public SMBLTable(String a, int b)
		{
			this.a = a;
			this.b = b;
		}
	}
	
	public static class ReservedWordFile{
		public final String lexeme; public final String a; public final int an; public final String b; public final int bn;
		public ReservedWordFile(String lexeme, String a, int an, String b, int bn)
		{
			this.lexeme = lexeme;
			this.a = a;
			this.an = an;
			this.b = b;
			this.bn = bn;
		}
	}
	
	public static boolean locate(String me)
	{
		for(SMBLTable i : Symbols)
		{
			if(i.a.equals(me))
			{
				return true;
			}
		}
		return false;
	}
	
	public static int valueOf(String me)
	{
		for(SMBLTable i : Symbols)
		{
			if(i.a.equals(me))
			{
				return i.b;
			}
		}
		return 0;
	}
	
	public static void initSMBL()
	{
		//Token-Type
		Symbols.add(new SMBLTable("relop", 1));
		Symbols.add(new SMBLTable("NUM", 2));
		Symbols.add(new SMBLTable("LEXERR", 3));
		Symbols.add(new SMBLTable("EOF", 2));
		Symbols.add(new SMBLTable("ADDOP", 2));
		Symbols.add(new SMBLTable("MulOP", 2));
		Symbols.add(new SMBLTable("ID", 7));
		Symbols.add(new SMBLTable("Period", 9));
		
		//Attribute
		Symbols.add(new SMBLTable("LE", 10));
		Symbols.add(new SMBLTable("NE", 11));
		Symbols.add(new SMBLTable("LT", 12));
		Symbols.add(new SMBLTable("EQ", 13));
		Symbols.add(new SMBLTable("GE", 14));
		Symbols.add(new SMBLTable("GT", 15));
		Symbols.add(new SMBLTable("INT", 16));
		Symbols.add(new SMBLTable("ExtraLongInteger", 17));
		Symbols.add(new SMBLTable("ExtraLongFloat", 18));
		Symbols.add(new SMBLTable("ExtraLongExponent", 19));
		Symbols.add(new SMBLTable("LeadingZero", 20));
		Symbols.add(new SMBLTable("TrailingZero", 21));
		Symbols.add(new SMBLTable("ExtraLongID", 22));
		Symbols.add(new SMBLTable("NULL", 23));
		Symbols.add(new SMBLTable("PLUS", 24));
		Symbols.add(new SMBLTable("MINUS", 25));
		Symbols.add(new SMBLTable("OR", 26));
		Symbols.add(new SMBLTable("AND", 27));
		Symbols.add(new SMBLTable("Divide", 28));
		Symbols.add(new SMBLTable("Mult", 29));
		Symbols.add(new SMBLTable("REAL", 30));
		Symbols.add(new SMBLTable("LONGREAL", 31));
		Symbols.add(new SMBLTable("Unrecognized", 32));
	}
	
	
	public static void main(String args[]) throws IOException
	{
		initSMBL();
		
		for(int i = 0; i < Integers.length; i++)
		{
			SetIntegers.add(Integers[i]);
		}
		for(int i = 0; i < Letters.length; i++)
		{
			SetLetters.add(Letters[i]);
		}
		
		String lines;
		int lineCounter = 1;
		
		File myFile = new File("keywordFile");
		File myOtherFile = new File("testme");
		
		Scanner input = new Scanner(myFile);	
		
		while(input.hasNextLine())
		{
			String l = input.next();
			RWF.add(new ReservedWordFile(l.substring(1, l.length()-1),input.next(),input.nextInt(),input.next(),input.nextInt()));
		}

		input = new Scanner(myOtherFile);
		
		while(input.hasNextLine())
		{
			lines = input.nextLine().toString();
			System.out.println(lineCounter + "   " + lines);
			for(int i = 0; i < buffer.length; i++)
			{
				if(i < lines.length())
				{buffer[i] = lines.substring(i, i+1);}
				else
				{buffer[i] = " ";}
			}
			

			b=0;
			while(b < buffer.length)
			{
				//System.out.println(b + " !" + buffer[b]+ "!");
				//Debugger Above
				IDres();
			}
			
			System.out.println("Listing File:");
			for(Token i : results)
			{
				if(i.a.equals("LEXERR"))
				{
					System.out.println(i.a + ":  " + i.b + ":  " + i.c);
				}
			}
			System.out.println();
			
			
			for(Token i : results)
			{
				TokenFile.add(lineCounter + " " + i.c + " " + i.a + "(" + valueOf(i.a) + ") "+ i.b + "(" + valueOf(i.b) + ")");
			}
			
			results.clear();
			lineCounter++;
		}
		
		TokenFile.add("  " + "eof" + " " + "EOF" + "(" + "4" + ") "+ "NULL" + "(" + "23" + ")");
		System.out.println("Token File: (line/lexeme/tokentype/attribute)");
		for(String i : TokenFile)
		{
			System.out.println(i);
		}
				
	}
	
	
	public static void relop()
	{
		int i=b;
			if(buffer[i].equals("<"))
			{
				i++;
				if(i < buffer.length)
				{
					if(buffer[i].equals("="))
					{
						results.add(new Token("relop","LE",buffer[i-1]+buffer[i]));
						i++;
						b=i;
						return;
					}
					else if(buffer[i].equals(">"))
					{
						results.add(new Token("relop","NE",buffer[i-1]+buffer[i]));
						i++;
						b=i;
						return;
					}
					else
					{
						results.add(new Token("relop","LT",buffer[i-1]));
						b=i;
						return;
					}
				}
				else
				{
					results.add(new Token("relop","LT",buffer[i-1]));
					b=i;
					return;
				}	
			}
			
			else if(buffer[i].equals("="))
			{
				results.add(new Token("relop","EQ",buffer[i]));
				i++;
				b=i;
				return;
			}
			
			else if(buffer[i].equals(">"))
			{
				i++;
				if(i < buffer.length)
				{
					if(buffer[i].equals("="))
					{
						results.add(new Token("relop","GE",buffer[i-1]+buffer[i]));
						i++;
						b=i;
						return;
					}
					else
					{
						results.add(new Token("relop","GE",buffer[i-1]));
						b=i;
						return;
					}
				}
				else
				{
					results.add(new Token("relop","GE",buffer[i-1]));
					b=i;
					return;
				}
			}
			else
			{
				results.add(new Token("LEXERR","Unrecognized",buffer[i]));
				i++;
				b=i;
				return;
			}
		
	}
	
	public static void whitespace()
	{
		int i=b;
			if((i+1)<buffer.length)
			{
				if((buffer[i]+buffer[i+1]).equals("/t"))
				{
					i=i+2;
					while(i<buffer.length)
					{
						if((i+1)<buffer.length)
						{
							if((buffer[i]+buffer[i+1]).equals("/t"))
							{
								i=i+2;
							}
							else if(buffer[i].equals(" "))
							{
								i++;
							}
							else
							{
								break;
							}
						}
						else if(buffer[i].equals(" "))
						{
							i++;
						}
						else
						{
							b=i;
							return;
						}
					}
					b=i;
					return;
				}
				else if(buffer[i].equals(" "))
				{
					i++;
					while(i<buffer.length)
					{
						if((i+1)<buffer.length)
						{
							if((buffer[i]+buffer[i+1]).equals("/t"))
							{
								i=i+2;
							}
							else if(buffer[i].equals(" "))
							{
								i++;
							}
							else
							{
								break;
							}
						}
						else if(buffer[i].equals(" "))
						{
							i++;
						}
						else
						{
							break;
						}
					}
					b=i;
					return;
				}
				else
				{
					catchAll();
				}
			}
			else if(buffer[i].equals(" "))
			{
				i++;
				b=i;
				return;
			}
			else
			{
				catchAll();
			}
	}
	
	public static void intMachine()
	{
		String number = "";
		int i = b;
		boolean LeadError = false;
		boolean overInt = false;
			if(SetIntegers.contains(buffer[i]))
			{
				number += buffer[i];
				i++;
				
				while(i < buffer.length)
				{
					if(SetIntegers.contains(buffer[i]))
					{
						number += buffer[i];
						i++;
					}
					else
					{
						break;
					}
				}
				
				if(number.substring(0, 1).equals("0") && number.length() > 1)
				{
					LeadError = true;
				}
				
				if(number.length() >= 10)
				{			
					overInt = true;
				}
				
				if(!(LeadError||overInt))
				{
					results.add(new Token("NUM", "INT", number));
					b=i;
					return;
				}
				else
				{
					b=i;
					if(LeadError)
					{
						results.add(new Token("LEXERR", "LeadingZero", number));
					}
					if(overInt)
					{
						results.add(new Token("LEXERR", "ExtraLongInteger", number));
					}
					return;
				}
				
			}
			else
			{
				relop();
			}
		
	}
	
	public static void IDres()
	{
		String ID = "";
		int i=b;
		
			if(SetLetters.contains(buffer[i]))
			{
				ID += buffer[i];
				i++;
				
				while(i<buffer.length)
				{
					if((SetLetters.contains(buffer[i])||SetIntegers.contains(buffer[i])))
					{
						ID += buffer[i];
						i++;
					}
					else
					{
						break;
					}
					
				}
				
				if(ID.length() <= 10)
				{
					if(ID.equals("eof"))//avoid using eof as ID
					{
						catchAll();
						return;
					}
					
					if(!keyword(ID))
					{
						if(locate(ID))
						{
							results.add(new Token("ID",ID,ID));
						}
						else
						{
							results.add(new Token("ID",ID,ID));
							Symbols.add(new SMBLTable(ID,IDpoint));
							IDpoint++;
						}

						
						b=i;
						return;
					}
					else
					{
						b=i;
						return;
					}
				}
				else
				{
					results.add(new Token("LEXERR","ExtraLongID",ID));
					b=i;
					return;
				}
			}
			else
			{
				whitespace();
			}
		}
	public static boolean keyword(String ID)
	{
		for(ReservedWordFile i : RWF)
		{
			if(ID.equals(i.lexeme))
			{
				if(!locate(i.a))
				{
					Symbols.add(new SMBLTable(i.a, i.an));
				}
				if(!locate(i.b))
				{
					Symbols.add(new SMBLTable(i.b, i.bn));
				}
				results.add(new Token(i.a,i.b,ID));
				return true;
				
			}
		}
		return false;
	}
	
	public static void real()
	{
		int i = b;
		String num = "";
		int numCounter = 0;
		boolean LeadError = false;
		boolean TrailError = false;
		boolean overInt = false;
		boolean overDec = false;
		
		if(SetIntegers.contains(buffer[i]))
		{
			if(buffer[i].equals("0")&&(i+1)<buffer.length)
			{
				if(SetIntegers.contains(buffer[i+1]))//in case of pure zero
				{
					LeadError = true;
				}
			}
			num += buffer[i];
			i++;
			numCounter++;
			
			while(i<buffer.length)
			{
				if(SetIntegers.contains(buffer[i]))
				{
					num += buffer[i];
					i++;
					numCounter++;
				}
				else
				{
					break;
				}
			}
			
			if(numCounter>=10)
			{
				overInt = true;
			}
			
			if(buffer[i].equals("."))
			{
				num += buffer[i];
				i++;
				numCounter = 0;
				
				while(i<buffer.length)
				{
					if(SetIntegers.contains(buffer[i]))
					{
						num += buffer[i];
						i++;
						numCounter++; 
					}
					else
					{
						break;
					}
				}
				
				if(num.substring(num.length()-1, num.length()).equals("0"))
				{
					TrailError = true;
				}
				if(numCounter >= 5)
				{
					overDec = true;
				}
				
				
					b=i;
					if(!(overInt||overDec||TrailError||LeadError))
					{
						results.add(new Token("NUM","REAL",num));
						return;
					}
					else
					{
						if(overDec||overInt)
						{
							results.add(new Token("LEXERR","ExtraLongFloat",num));
						}
						if(TrailError)
						{
							results.add(new Token("LEXERR","TrailingZero",num));
						}
						if(LeadError)
						{
							results.add(new Token("LEXERR","LeadingZero",num));
						}
						return;
					}
				
			}
			else
			{
				b=i;
				if(overInt)
				{
					if(LeadError)
					{
						results.add(new Token("LEXERR","LeadingZero",num));
						results.add(new Token("LEXERR","ExtraLongInteger",num));
						return;
					}
					else
					{
						results.add(new Token("LEXERR","ExtraLongInteger",num));
						return;
					}
				}
				else if(LeadError)
				{
					results.add(new Token("LEXERR","LeadingZero",num));
					return;
				}
				else
				{
					results.add(new Token("NUM","INT",num));
					return;
				}
			}
		}
		else
		{
			intMachine();
		}
	}
	
	public static void longreal()
	{
		int i = b;
		String num = "";
		int numCounter = 0;
		boolean LeadError = false;
		boolean TrailError = false;
		boolean overInt = false;
		boolean overDec = false;
		boolean overExp = false;
		
		if(SetIntegers.contains(buffer[i]))
		{
			if(buffer[i].equals("0")&&(i+1)<buffer.length)
			{
				if(SetIntegers.contains(buffer[i+1]))
				{
					LeadError = true;
				}
			}
			num += buffer[i];
			i++;
			numCounter++;
			
			while(i<buffer.length)
			{
				if(SetIntegers.contains(buffer[i]))
				{
					num += buffer[i];
					i++;
					numCounter++;
				}
				else
				{
					break;
				}
			}
			
			if(numCounter>=10)
			{
				overInt = true;
			}
			
			if(buffer[i].equals("."))
			{
				num += buffer[i];
				i++;
				numCounter = 0;
				
				while(i<buffer.length)
				{
					if(SetIntegers.contains(buffer[i]))
					{
						num += buffer[i];
						i++;
						numCounter++; 
					}
					else
					{
						break;
					}
				}
				
				if(num.substring(num.length()-1, num.length()).equals("0"))
				{
					TrailError = true;
				}
				if(numCounter >= 5)
				{
					overDec = true;
				}
				
				if(buffer[i].equals("E"))
				{
					num += buffer[i];
					i++;
					numCounter = 0;
					
					if(i<buffer.length)
					{
						if(buffer[i].equals("+")||buffer[i].equals("-"))
						{
							num += buffer[i];
							i++;
							
							if(i<buffer.length)
							{
								if(SetIntegers.contains(buffer[i]))
								{
									if(buffer[i].equals("0")&&(i+1)<buffer.length)
									{
										if(SetIntegers.contains(buffer[i+1]))
										{
											LeadError = true;
										}		
									}
									num += buffer[i];
									i++;
									numCounter++; 
								}
							}

							
							while(i<buffer.length)
							{
								if(SetIntegers.contains(buffer[i]))
								{
									num += buffer[i];
									i++;
									numCounter++; 
								}
								else
								{
									break;
								}
								
								
							}
						}
						
						else if(SetIntegers.contains(buffer[i]))
						{
							if(buffer[i].equals("0")&&(i+1)<buffer.length)
							{
								if(SetIntegers.contains(buffer[i+1]))//in case of pure zero
								{
									LeadError = true;
								}
							}
							num += buffer[i];
							i++;
							numCounter++;
							
							
							while(i<buffer.length)
							{
								if(SetIntegers.contains(buffer[i]))
								{
									num += buffer[i];
									i++;
									numCounter++; 
								}
								else
								{
									break;
								}
							}
							
							
						}
						
					}
					

					if(numCounter > 2)
					{
						overExp = true;
					}
					
					b=i;
					if(!(overInt||overDec||overExp||TrailError||LeadError))
					{
						results.add(new Token("NUM","LONGREAL",num));
						return;
					}
					else
					{
						b=i;
						if(overDec||overInt)
						{
							results.add(new Token("LEXERR","ExtraLongFloat",num));
						}
						if(overExp)
						{
							results.add(new Token("LEXERR","ExtraLongExponent",num)); 
						}
						if(TrailError)
						{
							results.add(new Token("LEXERR","TrailingZero",num));
						}
						if(LeadError)
						{
							results.add(new Token("LEXERR","LeadingZero",num));
						}
						return;
					}
				}
				else
				{
					b=i;
					if(!(overInt||overDec||TrailError||LeadError))
					{
						results.add(new Token("NUM","REAL",num));
						return;
					}
					else
					{
						if(overDec||overInt)
						{
							results.add(new Token("LEXERR","ExtraLongFloat",num));
						}
						if(TrailError)
						{
							results.add(new Token("LEXERR","Att.TrailingZero",num));
						}
						if(LeadError)
						{
							results.add(new Token("LEXERR","LeadingZero",num));
						}
						return;
					}
				}
			}
			else if(buffer[i].equals("E"))
			{
				num += buffer[i];
				i++;
				numCounter = 0;
				
				if(i<buffer.length)
				{
					if(buffer[i].equals("+")||buffer[i].equals("-"))
					{
						num += buffer[i];
						i++;
						
						if(i<buffer.length)
						{
							if(SetIntegers.contains(buffer[i]))
							{
								if(buffer[i].equals("0")&&(i+1)<buffer.length)
								{
									if(SetIntegers.contains(buffer[i+1]))//in case of pure zero
									{
										LeadError = true;
									}
								}
								num += buffer[i];
								i++;
								numCounter++; 
							}
						}
						
						while(i<buffer.length)
						{
							if(SetIntegers.contains(buffer[i]))
							{
								num += buffer[i];
								i++;
								numCounter++; 
							}
							else
							{
								break;
							}
							
							
						}
					}
					
					else if(SetIntegers.contains(buffer[i]))
					{
						if(buffer[i].equals("0")&&(i+1)<buffer.length)
						{
							if(SetIntegers.contains(buffer[i+1]))//in case of pure zero
							{
								LeadError = true;
							}
						}
						num += buffer[i];
						i++;
						numCounter++;
						
						while(i<buffer.length)
						{
							if(SetIntegers.contains(buffer[i]))
							{
								num += buffer[i];
								i++;
								numCounter++; 
							}
							else
							{
								break;
							}
						}
						
						
					}
					
				}
				
				if(numCounter > 2)
				{
					overExp = true;
				}
				
				b=i;
				if(!(overInt||overDec||overExp||TrailError||LeadError))
				{
					results.add(new Token("NUM","LONGREAL",num));
					return;
				}
				else
				{
					if(overDec||overInt)
					{
						results.add(new Token("LEXERR","ExtraLongInteger",num));
					}
					if(overExp)
					{
						results.add(new Token("LEXERR","ExtraLongExponent",num)); 
					}
					if(TrailError)
					{
						results.add(new Token("LEXERR","TrailingZero",num));
					}
					if(LeadError)
					{
						results.add(new Token("LEXERR","LeadingZero",num));
					}
					return;
				}
			}
			else
			{
				b=i;
				if(overInt)
				{
					if(LeadError)
					{
						results.add(new Token("LEXERR","LeadingZero",num));
						results.add(new Token("LEXERR","ExtraLongInteger",num));
						return;
					}
					else
					{
						results.add(new Token("LEXERR","ExtraLongInteger",num));
						return;
					}
				}
				else if(LeadError)
				{
					results.add(new Token("LEXERR","LeadingZero",num));
					return;
				}
				else
				{
					results.add(new Token("NUM","INT",num));
					return;
				}
			}
		}
		else
		{
			real();
		}
		
		
	}
	
	
	public static void catchAll()
	{
		int i = b;
			if((i+2)<buffer.length)
			{
				if((buffer[i]+buffer[i+1]+buffer[i+2]).equals("eof"))
				{
					results.add(new Token("EOF","NULL",buffer[i]+buffer[i+1]+buffer[i+2]));
					i = i+3;
					b=i;
					return;
				}
			}
			if((i+1)<buffer.length)
			{
				String twoStep = buffer[i]+buffer[i+1];
				if(twoStep.equals("/n"))
				{
					b=buffer.length;
					return;
				}
				else if(twoStep.equals("&&"))
				{
					results.add(new Token("MulOP","Att",twoStep));
					i=i+2;
					b=i;
					return;
				}
				else if(twoStep.equals("||"))
				{
					results.add(new Token("AddOP","OR",twoStep));
					i=i+2;
					b=i;
					return;
				}
				
				else if(buffer[i].equals("+"))
				{

							results.add(new Token("AddOP","Plus",buffer[i]));
							i++;
							b=i;
							return;				
				}
				else if(buffer[i].equals("-"))
				{
							results.add(new Token("AddOP","Minus",buffer[i]));
							i++;
							b=i;
							return;
				}
				else if(buffer[i].equals("*"))
				{
					results.add(new Token("MulOP","Mult",buffer[i]));
					i++;
					b=i;
					return;
				}
				else if(buffer[i].equals("/"))
				{
					results.add(new Token("MulOP","Divide",buffer[i]));
					i++;
					b=i;
					return;
				}
				else if(buffer[i].equals("."))
				{
							results.add(new Token("Period","NULL",buffer[i]));
							i++;
							b=i;
							return;
				}
				else
				{
					longreal();
				}
			}
			else if(buffer[i].equals("+"))
			{

						results.add(new Token("AddOP","Plus",buffer[i]));
						i++;
						b=i;
						return;				
			}
			else if(buffer[i].equals("-"))
			{
						results.add(new Token("AddOP","Minus",buffer[i]));
						i++;
						b=i;
						return;
			}
			else if(buffer[i].equals("*"))
			{
				results.add(new Token("MulOP","Mult",buffer[i]));
				i++;
				b=i;
				return;
			}
			else if(buffer[i].equals("/"))
			{
				results.add(new Token("MulOP","Divide",buffer[i]));
				i++;
				b=i;
				return;
			}
			else if(buffer[i].equals("."))
			{
						results.add(new Token("Period","NULL",buffer[i]));
						i++;
						b=i;
						return;
			}
			else
			{
				longreal();
			}	
		}
}
